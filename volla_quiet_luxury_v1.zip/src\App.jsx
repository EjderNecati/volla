import EtsySEOMaster from './components/EtsySEOMaster';
import './index.css';

function App() {
    return <EtsySEOMaster />;
}

export default App;
